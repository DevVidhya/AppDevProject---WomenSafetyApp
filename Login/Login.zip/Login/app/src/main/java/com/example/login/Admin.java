package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Admin extends AppCompatActivity {
    DatabaseHelper mydb2;
    private Button viewData;
    private EditText EnterEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        mydb2 = new DatabaseHelper(this);
        viewData = (Button)findViewById(R.id.button1);
        EnterEmail =(EditText)findViewById(R.id.etEnter);

        viewData.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = mydb2.getData();
                if(cursor.getCount()==0){
                    Toast.makeText(Admin.this,"No Data",Toast.LENGTH_LONG).show();
                }
                else{
                    while(cursor.moveToNext()){
                        Toast.makeText(Admin.this,"ID:"+cursor.getString(0)+" Mail:"+cursor.getString(2)+" Password: "+cursor.getString(3)+" ",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}
